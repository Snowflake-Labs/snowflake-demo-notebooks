import streamlit as st

def greeting():
  return "Hello world!"

def hi():
  st.write(greeting())

